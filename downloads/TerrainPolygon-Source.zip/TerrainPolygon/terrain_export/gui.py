import sys
from PySide6.QtCore import QThread, Signal
from PySide6.QtWidgets import (QApplication, QWidget, QFormLayout, QHBoxLayout, QVBoxLayout,
    QLineEdit, QPushButton, QFileDialog, QDoubleSpinBox, QSpinBox, QComboBox, QCheckBox,
    QTextEdit, QLabel, QMessageBox)
from terrain_export.engine import Options, extract


class Worker(QThread):
    message = Signal(str)
    result = Signal(bool, str)
    def __init__(self, options):
        super().__init__()
        self.options = options
    def run(self):
        try:
            count = extract(self.options, self.message.emit)
            self.result.emit(True, f'{count} polygons saved. / پلیگون ذخیره شد')
        except Exception as exc:
            self.result.emit(False, str(exc))


class Window(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Terrain Polygon Export — استخراج پلیگون ارتفاعی')
        self.resize(760, 640)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel('ورودی نقطه: بافر بر حسب متر | ورودی پلیگون: همان محدوده\nارتفاع بر حسب واحد عمودی فایل DEM/DSM است؛ ارتفاع ساختمان از زمین نیست.'))
        form = QFormLayout()
        layout.addLayout(form)
        self.vector = self.file_row(form, 'شیپ فایل نقطه / پلیگون', 'Shapefile (*.shp)')
        self.raster = self.file_row(form, 'DEM / DSM تک باند', 'Raster (*.tif *.tiff *.img *.asc);;All files (*)')
        self.output = self.file_row(form, 'خروجی پلیگونی', 'Shapefile (*.shp)', True)
        self.radius = self.number(100, 0.01, 1000000)
        form.addRow('شعاع بافر نقاط (متر)', self.radius)
        self.mode = QComboBox()
        self.mode.addItems(['بین دو ارتفاع (شامل مرزها)', 'بیشتر از حد پایین', 'کمتر از حد بالا'])
        form.addRow('شرط ارتفاع', self.mode)
        self.minimum = self.number(30)
        self.maximum = self.number(100)
        form.addRow('حد پایین', self.minimum)
        form.addRow('حد بالا', self.maximum)
        self.mode.currentIndexChanged.connect(self.update_limits)
        self.workers = QSpinBox()
        self.workers.setRange(1, 256)
        self.workers.setValue(min(256, Options('', '', '').workers))
        form.addRow('تعداد پردازش موازی CPU', self.workers)
        self.gpu = QCheckBox('استفاده از CUDA در صورت نصب (در غیر این صورت CPU)')
        form.addRow(self.gpu)
        self.run_button = QPushButton('پردازش و ذخیره Shapefile')
        self.run_button.clicked.connect(self.start)
        layout.addWidget(self.run_button)
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        layout.addWidget(self.log)
        self.worker = None
    def update_limits(self):
        self.minimum.setEnabled(self.mode.currentIndex() != 2)
        self.maximum.setEnabled(self.mode.currentIndex() != 1)
    def number(self, value, low=-100000, high=100000):
        box = QDoubleSpinBox()
        box.setRange(low, high)
        box.setDecimals(3)
        box.setValue(value)
        return box
    def file_row(self, form, title, pattern, save=False):
        row = QHBoxLayout()
        edit = QLineEdit()
        button = QPushButton('انتخاب…')
        def choose():
            dialog = QFileDialog.getSaveFileName if save else QFileDialog.getOpenFileName
            name, _ = dialog(self, title, '', pattern)
            if name:
                edit.setText(name if not save or name.lower().endswith('.shp') else name + '.shp')
        button.clicked.connect(choose)
        row.addWidget(edit)
        row.addWidget(button)
        form.addRow(title, row)
        return edit
    def start(self):
        o = Options(self.vector.text(), self.raster.text(), self.output.text(),
                    ['between', 'above', 'below'][self.mode.currentIndex()], self.minimum.value(),
                    self.maximum.value(), self.radius.value(), self.gpu.isChecked(), self.workers.value())
        if not all((o.vector, o.raster, o.output)):
            QMessageBox.warning(self, 'ورودی ناقص', 'هر سه مسیر فایل را انتخاب کنید.')
            return
        self.run_button.setEnabled(False)
        self.log.clear()
        self.worker = Worker(o)
        self.worker.message.connect(self.log.append)
        self.worker.result.connect(self.done)
        self.worker.finished.connect(lambda: self.run_button.setEnabled(True))
        self.worker.start()
    def done(self, success, message):
        self.log.append(message)
        if not success:
            QMessageBox.warning(self, 'خطای پردازش', message)
    def closeEvent(self, event):
        if self.worker and self.worker.isRunning():
            QMessageBox.information(self, 'پردازش فعال', 'برای جلوگیری از خرابی خروجی تا پایان پردازش صبر کنید.')
            event.ignore()
        else:
            event.accept()


def main():
    app = QApplication(sys.argv)
    window = Window()
    window.show()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
