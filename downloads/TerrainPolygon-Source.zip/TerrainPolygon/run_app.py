import sys

if __name__ == '__main__':
    if '--self-test' in sys.argv:
        import json
        import traceback
        from pathlib import Path
        report = Path(sys.argv[sys.argv.index('--self-test') + 1])
        try:
            from terrain_export.selftest import run
            result = run()
            from PySide6.QtWidgets import QApplication
            from terrain_export.gui import Window
            app = QApplication([])
            window = Window()
            window.show()
            app.processEvents()
            window.close()
            result["gui"] = "opened and closed"
            report.write_text(json.dumps(result, indent=2), encoding='utf-8')
        except Exception:
            report.write_text(json.dumps({'status': 'failed', 'error': traceback.format_exc()}, indent=2), encoding='utf-8')
            sys.exit(1)
    elif '--smoke-test' in sys.argv:
        from PySide6.QtWidgets import QApplication
        from terrain_export.gui import Window
        app = QApplication([])
        window = Window()
        window.show()
        app.processEvents()
        window.close()
    else:
        from terrain_export.gui import main
        main()
